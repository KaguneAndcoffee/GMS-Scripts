# MSEA v174.3 Scripts

-----

## When posting/updating scripts:
- Use full names. "No Delay", not "ND"
- post scripts to their proper version folder so there's no need for commenting versions
- add an AoB wherever needed "12345678: //11 22 33 44"

## Tags allowed:
- **//not working** - the script is not working so Nexon'd Trainer will prevent users from using it
- **//override** - the script contains instruction errors if not attached to MapleStory first, but will be loaded into the trainer anyways
