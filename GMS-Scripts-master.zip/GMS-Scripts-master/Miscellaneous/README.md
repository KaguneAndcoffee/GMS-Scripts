# MapleStory Script Bank - MISC SECTION
Various misc files goes here.

-----

## Submit old Cheat Tables
Got an old cheat table or two? Fork this repository, upload the cheat table(s), and submit a [pull request](https://github.com/md35-gk/GMS-Script-Bank/pulls).

## The AoB Project (a work-in-progress)
Updates can break certain AoBs in scripts. By providing a memory region copy, we can determine how that AoB changed, and may even create a new one entirely if needed.
